define("epi-ecf-ui/contentediting/editors/InventoryOverviewEditor", [
// Dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/dom-construct",
    "dojo/when",

    // DGrid
    "dgrid/OnDemandGrid",
    "dgrid/Selection",
    "dgrid/selector",
    "dgrid/extensions/ColumnResizer",
    "dgrid/editor",

    // EPi
    "epi/shell/dgrid/_EditorMetadataMixin",
    "epi/shell/dgrid/Formatter",

    //epi-CMS
    "epi-cms/dgrid/WithContextMenu",
    "epi-cms/dgrid/formatters",

    // epi commerce
    "./_OverviewEditorBase",
    "./CheckBoxEditor",
    "../viewmodel/InventoryOverviewEditorModel",

    //resources
    "epi/i18n!epi/cms/nls/commerce.widget.inventoryoverview.grid",
    "epi/i18n!epi/cms/nls/commerce.widget.inventorycollection.message"
],
function (
    // Dojo
    array,
    declare,
    lang,
    aspect,
    domConstruct,
    when,

    // DGrid
    OnDemandGrid,
    Selection,
    selector,
    ColumnResizer,
    editor,

    // EPi
    _EditorMetadataMixin,
    Formatter,

    //epi-CMS
    WithContextMenu,
    formatters,

    // epi commerce
    _OverviewEditorBase,
    Checkbox,
    InventoryOverviewEditorModel,

    // Resources
    resources,
    messageResources
) {
    return declare([_OverviewEditorBase], {

        grid: null,

        modelType: InventoryOverviewEditorModel,

        itemType: "EPiServer.Commerce.Shell.ObjectEditing.InternalMetadata.InventoryRecordModel",

        activeEditor: null,

        includedColumns: ["WarehouseCode", "CatalogEntryCode", "IsTracked", "PurchaseAvailabeQuantity", "PurchaseAvailableUtc", "BackorderAvailableQuantity", "BackorderAvailableUtc", "PreorderQuantity", "PreorderAvailableUtc", "ReorderMinQuantity"],

        editableColumns: ["IsTracked", "PurchaseAvailabeQuantity", "PurchaseAvailableUtc", "BackorderAvailableQuantity", "BackorderAvailableUtc", "PreorderQuantity", "PreorderAvailableUtc", "ReorderMinQuantity"],

        additionalEditorGridSettings: null,

        editorGrid: null,

        storeKey: "epi.commerce.inventory",

        title: resources.commands.title,

        _noDataMessage: resources.nodatamessage,

        postMixInProperties: function () {
            this.model = this.model || new this.modelType({
                itemType: this.itemType
            });
        },

        postCreate: function () {
            // Set up metadata capable grid type
            this.editorGrid = declare([OnDemandGrid, Selection, Formatter, _EditorMetadataMixin, ColumnResizer, WithContextMenu]);
            this.additionalEditorGridSettings = { getBeforePut: false, sort: ["WarehouseCode"] };
            
            this.inherited(arguments);
        },

        _setupEvents: function (grid) {
            this.own(grid,
                grid.on("dgrid-editor-show", lang.hitch(this, function (e) {
                    this.activeEditor = e.editor;
                    this._showEditorInPopup(e);
                })),
                grid.on("dgrid-datachange", lang.hitch(this, function (e) {
                    //invalid value will result in no changes to the inventory row.
                    if (this.activeEditor && this.activeEditor.isValid && !this.activeEditor.isValid()) {
                        e.preventDefault();
                    }
                })),
                grid.on(".epi-iconContextMenu:click", lang.hitch(this, this.onContextMenuClick)),
                this.model.watch("contentLink", lang.hitch(this, this._changeGridQuery)),
                this.model.on("itemAdded", lang.hitch(this, function(e) {
                    this.grid.refresh();
                })),
                this.model.on("itemsRemoved", lang.hitch(this, function(e) {
                    this.grid.refresh();
                })),
                // Listen remove command event
                this.model.on("removeCommandEvent", lang.hitch(this, function() {
                    // Show confirmation dialog to confirm delete inventory item
                    when(this._showConfirmation(resources.deleteconfirmation.inventorytitle, resources.deleteconfirmation.inventorydescription), lang.hitch(this, function () {
                        if (this.model) {
                            return this.model.removeItems([this.selectedRecord]);
                        }
                    }));
                }))
            );
        },

        _showEditorInPopup: function (e) {
            //we're wrapping the editor in a div to give it a popup styling.
            var popupElement = domConstruct.create("div", { "class": "epi-dgrid-popup" }, e.cell.element, "last");
            var editorWrapper = domConstruct.create("div", { "class": "epi-dgrid-popup__content" }, popupElement, "last");

            domConstruct.place(e.editor.domNode, editorWrapper);

            if (e.editor instanceof (Checkbox)) {
                var labelNode = '<label style="margin:10px;" for="' + e.editor.checkbox.get("id") + '">' + e.editor.get("label") + '</label>';
                domConstruct.place(labelNode, editorWrapper);
            }

            domConstruct.place(this.currentEditorHtmlValue, e.cell.element, "first");

            // reset the editor's content box so when FormContainer do the layout, it will resize
            // its children based on their actual size, not the specific one, which has the incorrect value.
            e.editor._contentBox = null;

            var beforeBlurHandle = aspect.before(e.editor, "onBlur", function () {
                //we need to move the editor back to the grid before "blur"
                //so that the dgrid/editor plugin can do its save/"hide editor" magic

                //move the editor to a temporary div first to prevent issues in IE
                //when we move the editors domNode as the only child to e.cell.element
                var tempDiv = domConstruct.create("div");
                domConstruct.place(e.editor.domNode, tempDiv);
                //then move it as the only child to the element we're editing.
                domConstruct.place(e.editor.domNode, e.cell.element, "only");
                beforeBlurHandle.remove();
            });
        }
    });
});
