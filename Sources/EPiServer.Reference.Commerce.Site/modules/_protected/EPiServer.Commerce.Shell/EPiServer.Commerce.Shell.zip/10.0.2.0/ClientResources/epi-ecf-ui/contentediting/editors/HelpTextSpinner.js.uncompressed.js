require({cache:{
'url:epi-ecf-ui/contentediting/editors/templates/HelpTextSpinner.html':"﻿<div class=\"dijitInline\" tabindex=\"-1\" role=\"presentation\">\n    <div data-dojo-attach-point=\"numberSpinner\" data-dojo-type=\"dijit/form/NumberSpinner\"></div>\n    <div><span>${helptext}</span></div>\n</div>"}});
﻿define("epi-ecf-ui/contentediting/editors/HelpTextSpinner", [
    // dojo
    "dojo/_base/declare",
    // dijit
    "dijit/_Widget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/form/NumberSpinner",
    // epi
    "epi/shell/widget/_ValueRequiredMixin",
    // template
    "dojo/text!./templates/HelpTextSpinner.html",
    // resources
    "epi/i18n!epi/cms/nls/commerce.widget.redemptionlimitdata"
],
function (
    // dojo
    declare,
    // dijit
    _Widget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
    NumberSpinner,
    // epi
    _ValueRequiredMixin,
    // template
    template,
    // resources
    resources
) {
    return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin, _ValueRequiredMixin], {
        // module:
        //  epi-ecf-ui/contentediting/editors/HelpTextSpinner
        // summary:
        //    NumberSpinner with a descriptive help text renderred under the input control.
        // tags:
        //    public

        templateString: template,

        helptext: null,

        postMixInProperties: function () {
            this.inherited(arguments);

            if (this.name) {
                this.helptext = resources[this._parsePropertyName(this.name)];
            }
        },

        _parsePropertyName: function (name) {

            // Inspects a string and returns the trailing part from the
            // last period found. In the absence of periods the full name is returned.
            var index = name.lastIndexOf(".") + 1;
            var propertyName = name;

            if (index > 0) {
                propertyName = propertyName.slice(index);
            }

            return propertyName.toLowerCase();
        },

        _setTooltipAttr: function (value) {
            this.numberSpinner.set("tooltip", value);
        },

        _setIsLanguageSpecificAttr: function (value) {
            this.numberSpinner.set("isLanguageSpecific", value);
        },

        _setInvalidMessageAttr: function (value) {
            this.numberSpinner.set("invalidMessage", value);
        },

        _setConstraintsAttr: function (value) {
            this.numberSpinner.set("constraints", value);
        },

        _setPlaceHolderAttr: function (value) {
            this.numberSpinner.set("placeHolder", value);
        },

        _setValueAttr: function (value) {
            this.numberSpinner.set("value", value);
            this._set("value", value);
        },

        _getValueAttr: function () {
            return this.numberSpinner.get("value");
        },

        isValid: function () {
            return this.inherited(arguments) && this.numberSpinner.isValid();
        }
    });
});