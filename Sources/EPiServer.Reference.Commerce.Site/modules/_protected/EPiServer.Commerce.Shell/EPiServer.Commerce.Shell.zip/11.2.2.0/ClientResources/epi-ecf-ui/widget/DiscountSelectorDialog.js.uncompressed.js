require({cache:{
'url:epi-ecf-ui/widget/templates/_SelectorDialog.html':"﻿<div>\r\n    <div class=\"epi-searchbox-container\">\r\n        <div data-dojo-type=\"epi/shell/widget/SearchBox\" data-dojo-attach-point=\"searchBox\"\r\n             class=\"epi-search--full-width\" data-dojo-attach-event=\"onSearchBoxChange:_onSearchBoxChange\"\r\n             data-dojo-props=\"placeHolder: '${resources.searchplaceholder}', triggerChangeOnEnter: false\"></div>\r\n    </div>\r\n    <div data-dojo-attach-point=\"noDataMessage\" style=\"display:none\" class=\"dgrid-no-data\">${noDataMessageResources.nosearchresults}</div>\r\n    <div data-dojo-attach-point=\"listContainer\" />\r\n</div>"}});
﻿define("epi-ecf-ui/widget/DiscountSelectorDialog", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-style",
    "dojo/keys",
// dijit
    "dijit/layout/_LayoutWidget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
// epi
    "epi/shell/widget/SearchBox",
    "epi/string",
// epi-ecf-ui
    "./DiscountTree",
// resources
    "dojo/text!./templates/_SelectorDialog.html",
    "epi/i18n!epi/nls/commerce.widget.discountselector",
    "epi/i18n!epi/cms/nls/episerver.cms.widget.hierachicallist"
],

function (
// dojo
    declare,
    lang,
    domStyle,
    keys,
// dijit
    _LayoutWidget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
// epi
    SearchBox,
    epiString,
// epi-ecf-ui
    DiscountTree,
// resources
    templates,
    resources,
    noDataMessageResources
) {
    return declare([_LayoutWidget, _TemplatedMixin, _WidgetsInTemplateMixin], {
        // summary:
        //      Represents the widget which contains the discount tree.
        // tags:
        //    internal product

        // templateString: [protected] String
        //      Widget's template string.
        templateString: templates,

        resources: resources,

        noDataMessageResources: noDataMessageResources,

        _tree: null,

        postCreate: function () {
            this.inherited(arguments);
            this._tree = this._tree || new DiscountTree({
               root: this.root,
               store: this.store
            }, this.listContainer);

            this.own(this._tree,
                    this._tree.on("filter", lang.hitch(this, this._styleSelector)),
                    this.searchBox.on("keyup", lang.hitch(this, this._onSearchBoxKeyUp)),
                    this.on("show", lang.hitch(this, function () {
                        this.searchBox.clearValue();
                    }))
            );
        },

        _setExcludedLinkAttr: function (value) {
            this._tree.model.set("excludedLink", value);
        },

        _setCheckedItemsAttr: function (value) {
            this._tree.set("checkedItems", value);
        },

        _getCheckedItemsAttr: function (value) {
            return this._tree.get("checkedItems");
        },

        _onSearchBoxChange: function (queryText) {
            // summary:
            //      handle searchBoxChange event.
            // queryText: [string]
            //      the query text to filter promotion data.
            // tags:
            //      Private

            this._tree.set("searchText", queryText);
        },

        _onSearchBoxKeyUp: function (evt) {
            // summary:
            //      pressing a key when searching promotions.
            // tags:
            //      private

            if (evt.keyCode === keys.ENTER) {
                if(epiString.isNullOrEmpty(this.searchBox.get("value"))) {
                    return;
                }

                var node = this._tree.get("firstPromotionNode");
                if (!node.item.hidden && !node.item.disable) {
                    node.set("checked", !node.get("checked"));
                    node.onNodeClicked();
                    return true;
                }
            }
        },

        _styleSelector: function (evt) {
            // summary:
            //      style items after filtering promotion data.
            // evt: object
            //      The event arguments.
            // tags:
            //      Private

            domStyle.set(this.noDataMessage, "display", evt.searchFound ? "none" : "");
            domStyle.set(this._tree.domNode, "display", evt.searchFound ? "" : "none");
        }
    });
});