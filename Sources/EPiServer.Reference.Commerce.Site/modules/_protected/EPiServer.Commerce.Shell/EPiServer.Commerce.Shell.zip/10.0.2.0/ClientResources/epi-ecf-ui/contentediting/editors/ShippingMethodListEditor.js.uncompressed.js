﻿define("epi-ecf-ui/contentediting/editors/ShippingMethodListEditor", [
// dojo
    "dojo/_base/declare",
    "dojo/dom-construct",
//epi-cms
    "epi-cms/contentediting/editors/CheckBoxListEditor",
// resources
    "epi/i18n!epi/cms/nls/commerce.widget.shippingmethodlisteditor"
], function (
// dojo
    declare,
    domConstruct,
// epi-cms
    CheckBoxListEditor,
// resources
    resources
) {
    return declare([CheckBoxListEditor], {
        // summary:
        //      A widget used to edit a list of shipping method.
        // tags:
        //      internal

        buildRendering: function () {
            this.inherited(arguments);

            if(!this.selections.length) {
                this._createNoShippingMethodsNode();
            }            
        },

        _createNoShippingMethodsNode: function () {
            var label = domConstruct.create("div", { "class": "dgrid-no-data dgrid-no-data--left-aligned" }, this.domNode);
            label.textContent = resources.noshippingmethods;
        }
    });
});