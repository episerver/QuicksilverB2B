require({cache:{
'url:epi-ecf-ui/contentediting/templates/GridFormContainer.html':"<div class='epi-containerLayout clearfix'>\n    <div class='epi-formsHeaderContainer'>\n        <h2>${title}</h2>\n        <p data-dojo-attach-point='helpTextNode'></p>\n    </div>\n    <ul data-dojo-attach-point='containerNode'></ul>\n</div>"}});
define("epi-ecf-ui/contentediting/GridFormContainer", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/when",
// epi
    "epi/shell/TypeDescriptorManager",
    "epi/shell/layout/SimpleContainer",
// epi-cms
    "epi-cms/_ContentContextMixin",
// resources
    "dojo/text!./templates/GridFormContainer.html"
], function(
// dojo
    declare,
    lang,
    when,
// epi
    TypeDescriptorManager,
    SimpleContainer,
// epi-cms
    _ContentContextMixin,
// resources
    template
){
    return declare([SimpleContainer, _ContentContextMixin], {

        templateString: template,

        typeDescriptorManager: TypeDescriptorManager,

        buildRendering: function(){
            this.inherited(arguments);

            when(this.getCurrentContent()).then(lang.hitch(this, function (currentContext) {
                var specificGroupResources;
                var allGroupResources = this.typeDescriptorManager.getResourceValue(currentContext.typeIdentifier, "groups");

                if (allGroupResources) {
                    specificGroupResources = allGroupResources[this.name.toLowerCase()];
                }

                if (specificGroupResources && specificGroupResources.help) {
                    this.set("helpText", specificGroupResources.help);
                }
            }));
            
        },

        _setHelpTextAttr: { node: "helpTextNode", type: "innerHTML" }
    });
});