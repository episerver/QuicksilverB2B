﻿define("epi-ecf-ui/widget/CampaignItemList", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/event",
    "dojo/_base/lang",
    "dojo/dom-class",
    "dojo/html",
    "dojo/keys",
    "dojo/query",
    "dojo/when",
// epi
    "epi",
    "epi/dependency",
    "epi/shell/command/builder/ButtonBuilder",
// commerce
    "./viewmodel/CampaignItemListModel",
    "../MarketingUtils",
    "./_MarketingListBase",
// resources
    "epi/i18n!epi/nls/commerce.widget.marketingitemlist"
],
function (
// dojo
    declare,
    event,
    lang,
    domClass,
    html,
    keys,
    query,
    when,
// epi
    epi,
    dependency,
    ButtonBuilder,
// commerce
    CampaignItemListModel,
    MarketingUtils,
    _MarketingListBase,
// resources
    resources
) {
    return declare([_MarketingListBase], {
        typeIdentifiers: [
            MarketingUtils.contentTypeIdentifier.salesCampaign,
            MarketingUtils.contentTypeIdentifier.promotionData
        ],

        withDeleteButton: false,

        postMixInProperties: function () {
            this._facetFiltersService = this._facetFiltersService || dependency.resolve("epi.commerce.FacetFiltersService");
            this.inherited(arguments);
        },

        buildRendering: function () {
            // summary:
            //		Construct the UI for this widget with this.domNode initialized as a dgrid.
            // tags:
            //		protected

            this.inherited(arguments);

            this._modifyStoreToHandleDgridTree();
        },

        postCreate: function () {
            // tags:
            //      extensions

            this.inherited(arguments);

            domClass.add(this.grid.domNode, "epi-campaign-list");
        },

        getQuery: function (parentId) {
            return {
                query: this.queryName,
                referenceId: parentId,
                typeIdentifiers: this.typeIdentifiers,
                campaignFacets: this._facetFiltersService.getFiltersAsJson()
            };
        },

        createModel: function () {
            return new CampaignItemListModel({
                store: this.store
            });
        },

        getListSettings: function () {
            var settings = this.inherited(arguments);
            if (this.withDeleteButton) {
                this._replaceContextMenuByDeleteButton(settings.columns);
            }

            var self = this;
            return lang.mixin(this.defaultGridMixin, lang.mixin(settings, {
                dndDisabled: true,
                showHeader: false,
                renderArray: function () {
                    return when(this.inherited(arguments), function (results) {
                        //After calling the inherited renderArray function we clear the noDataNode.
                        //This forces the grid to create a new node every time a campaign does not have any promotion.
                        self.grid.noDataNode = null;

                        if (results.length > 0) {
                            var contentLinks = [], shouldUpdateRedemptions = true;
                            for (var i = 0, length = results.length; i < length; i++) {
                                var itemData = self.grid.row(results[i]).data;
                                contentLinks.push(itemData.contentLink);
                                shouldUpdateRedemptions &= MarketingUtils.isPromotionData(itemData.typeIdentifier);
                            }
                            self._updateOrderCounts(contentLinks);
                            if (shouldUpdateRedemptions) {
                                self._updateRedemptions(contentLinks);
                            }
                        }

                        return results;
                    });
                },
                onContextMenuClick: function (e) {
                    this.inherited(arguments);
                    self.onContextMenuClick(e);
                }
            }));
        },

        _updateOrderCounts: function (contentLinks) {
            // summary:
            //      Updates order count statistic for each campaign.
            // contentLinks: [Array]
            //      Collection of campaign/promotion link.
            // tags:
            //      private

            when(this.model.getOrderCounts(contentLinks), lang.hitch(this, function (results) {
                if (!(results instanceof Array) || results.length === 0) {
                    return;
                }

                var gridId = this.grid.id;
                for (var i = 0, length = results.length; i < length; i++) {
                    var orderCountNode = query("#" + gridId + "-row-" + results[i].contentLink + " .field-ordertotal .epi-primaryText")[0];
                    orderCountNode && html.set(orderCountNode, results[i].orderCount.toString());
                }
            }));
        },

        _updateRedemptions: function (promotionLinks) {
            // summary:
            //      Updates redemptions for each promotion.
            // promotionLinks: [Array]
            //      Collection of promotion link.
            // tags:
            //      private

            when(this.model.getRedemptions(promotionLinks), lang.hitch(this, function (results) {
                if (!(results instanceof Array) || results.length === 0) {
                    return;
                }

                var gridId = this.grid.id;
                for (var i = 0, length = results.length; i < length; i++) {
                    var redemptionNode = query("#" + gridId + "-row-" + results[i].contentLink + " .field-redemptions .epi-primaryText")[0];
                    redemptionNode && html.set(redemptionNode, results[i].totalRedemptions.toString());
                }
            }));
        },

        setupEvents: function () {
            this.inherited(arguments);
            this.grid.addKeyHandler(keys.DELETE, lang.hitch(this, function (e) {
                var row = this.grid.row(e);
                var deleteCommand = this.model.createDeleteCommand();
                deleteCommand.set("model", row.data);
                deleteCommand.execute();
            }));
            this._setupOnStoreItemDeleted();
        },

        _modifyStoreToHandleDgridTree: function () {
            // summary:
            //      getChildren and mayHaveChildren are needed on the store
            //      for dgrids tree module to work.
            // tags:
            //      private
            var self = this;
            this.store = lang.mixin(this.store, {
                getChildren: function (parent, options) {
                    return this.query(self.getQuery(parent.contentLink), options);
                },
                mayHaveChildren: function (parent) {
                    // only campaigns have children
                    return MarketingUtils.isSalesCampaign(parent.typeIdentifier);
                }
            });
        },

        onContextMenuClick: function (e) {
            this.inherited(arguments);
            var row = this.grid.row(e);
            this.model.updateCommandModel(row.data);
        },

        _replaceContextMenuByDeleteButton: function (columnSettings) {
            columnSettings = lang.mixin(columnSettings, {
                contextMenu: {
                    renderHeaderCell: function () { }, // no header
                    renderCell: lang.hitch(this, function (object, value, node, options) {
                        var deleteCommand = this.model.createDeleteCommand(false);
                        var builder = new ButtonBuilder({
                            settings: {
                                showLabel: false,
                                "class": "epi-chromeless",
                                onKeyDown: function (e) {
                                    if (e.keyCode === keys.ENTER) {
                                        //when pressing ENTER on button
                                        //we need to stop the grids key
                                        //handler changing context.
                                        event.stop(e);
                                    }
                                }
                            }
                        });
                        deleteCommand.set("model", object);
                        builder.create(deleteCommand, node);
                    }),
                    className: "epi-columnNarrow",
                    sortable: false
                }
            });
        },

        _setupOnStoreItemDeleted: function () {
            if (epi.isEmpty(this.store) || typeof this.store.on !== "function") {
                return;
            }

            this.own(
                this.store.on("delete", lang.hitch(this, function (deletedItem) {
                    var deleted = !!(deletedItem && deletedItem.id);
                    deleted && this.grid && this.grid.refresh();
                }))
            );
        }
    });
});