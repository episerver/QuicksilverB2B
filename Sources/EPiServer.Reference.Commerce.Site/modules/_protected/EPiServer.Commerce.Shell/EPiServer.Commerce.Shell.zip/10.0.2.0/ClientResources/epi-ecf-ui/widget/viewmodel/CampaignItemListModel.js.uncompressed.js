﻿define("epi-ecf-ui/widget/viewmodel/CampaignItemListModel", [
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
// epi-cms
    "epi/shell/command/_Command",
    "epi-cms/component/command/ChangeContext",
    "epi-cms/command/NewContent",
// epi-ecf-ui
    "../../MarketingUtils",
    "../DeleteCampaignItemDialog",
    "./_MarketingListBaseModel",
// resources
    "epi/i18n!epi/nls/commerce.widget.marketingitemlist",
    "epi/i18n!epi/nls/episerver.shared"
],
function (
// dojo
    array,
    declare,
    lang,
// epi-cms
    _Command,
    ChangeContext,
    NewContent,
// epi-ecf-ui
    MarketingUtils,
    DeleteCampaignItemDialog,
    _MarketingListBaseModel,
// resources
    resources,
    sharedResources
) {
    return declare([_MarketingListBaseModel], {

        postscript: function () {
            this.inherited(arguments);
            this._setupCommands();
        },

        _setupCommands: function () {
            // Reset commands list.
            this.commands.length = 0;

            this.commands.push(new ChangeContext({
                category: "context",
                forceContextChange: true
            }));

            this.commands.push(new NewContent({
                category: "context",
                contentType: MarketingUtils.contentTypeIdentifier.promotionData,
                label: resources.createpromotion
            }));

            this.commands.push(this.createDeleteCommand(true));
        },

        createDeleteCommand: function (useContextMenu) {
            var deleteCommand = new _Command({
                store: this.store,
                iconClass: "epi-iconClose",
                label: sharedResources.action.deletelabel,
                canExecute: false,
                _onModelChange: function () {
                    this.set("canExecute", !!this.get("model"));
                },
                _execute: function () {
                    var dialog = new DeleteCampaignItemDialog({
                        contentData: this.get("model"),
                        store: this.store
                    });
                    dialog.show();
                }
            });

            if (useContextMenu) {
                deleteCommand.set("category", "context");
            }
            
            return deleteCommand;
        }
    });
});