﻿define("epi-ecf-ui/widget/_ConfirmDiscardChangesMixin", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/topic",
// dijit
    "dijit/_WidgetBase",
// resources
    "epi/i18n!epi/cms/nls/commerce.widget.gridformview"
], function (
// dojo
    declare,
    lang,
    aspect,
    topic,
// dijit
    _WidgetBase,
// resources
    resources
) {
    return declare([_WidgetBase], {
        // summary:
        //      Represents a mixin class to display a confirmation for discarding changes before leaving the form.
        // tags:
        //      public

        // contextChangeStrings: Array
        //      Collection of publish event name
        // tags:
        //      protected
        contextChangeStrings: [
            "/epi/shell/context/request",
            "/epi/shell/action/changeview",
            "/epi/shell/action/changeview/back"
        ],

        _onBeforeUnloadListener: null,

        postCreate: function () {
            this.inherited(arguments);

            this.own(aspect.around(topic, "publish", lang.hitch(this, "_aroundTopicPublish")));
            this._onBeforeUnloadListener = lang.hitch(this, "_onBeforeUnload");
            window.addEventListener("beforeunload", this._onBeforeUnloadListener);
        },

        destroy: function () {
            this.inherited(arguments);
            if (this._onBeforeUnloadListener) {
                window.removeEventListener("beforeunload", this._onBeforeUnloadListener);
            }
        },

        _onBeforeUnload: function (e) {
            if (!this.changesSaved()) {
                e.returnValue = resources.warnunsavedchanges;
                return resources.warnunsavedchanges;
            }
        },

        _aroundTopicPublish: function (original) {
            return lang.hitch(this, function (item) {
                if (!this._isContextChangeRequest(item) || this.changesSaved()) {
                    return original.apply(topic, arguments);
                }

                if (this.confirmDiscardChanges()) {
                    this.discardChanges();
                    return original.apply(topic, arguments);
                }
            });
        },

        _isContextChangeRequest: function (requestString) {
            return requestString && this.contextChangeStrings.indexOf(requestString) >= 0;
        },

        confirmDiscardChanges: function () {
            // summary:
            //      Show a confirmation box to confirm discard changes.
            // tags:
            //      protected
            return window.confirm(resources.warnunsavedchanges + " " + resources.confirmdiscarchanges);
        },

        changesSaved: function () {
            // summary:
            //      Indicates those changes are saved.
            // return:
            //      boolean
            // tags:
            //      protected
            if (this.model) {
                return !this.model.get("hasPendingChanges");
            }
            return true;
        },

        discardChanges: function () {
            // summary:
            //      Discard any changes.
            // tags:
            //      protected
            if (this.model) {
                this.model.set("hasPendingChanges", false);
            }
        }
    });
});