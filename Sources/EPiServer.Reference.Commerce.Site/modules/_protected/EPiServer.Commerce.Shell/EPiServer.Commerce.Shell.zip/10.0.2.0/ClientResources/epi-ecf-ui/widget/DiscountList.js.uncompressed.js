require({cache:{
'url:epi-ecf-ui/widget/viewmodel/templates/DatePeriodColumnHeader.html':"﻿<h1>${headingLabel}</h1>\n<h2>${fromDate} - ${toDate}</h2>"}});
﻿define("epi-ecf-ui/widget/DiscountList", [
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/promise/all",
    "dojo/string",
    "dojo/when",
// epi
    "epi/datetime",
    "epi/shell/widget/_ModelBindingMixin",
// epi-cms
    "epi-cms/core/ContentReference",
// epi-ecf-ui
    "../MarketingUtils",
    "./_ConfirmDiscardChangesMixin",
    "./_MarketingListBase",
    "./DiscountSelector",
    "./viewmodel/DiscountListModel",
// resources
    "epi/i18n!epi/nls/commerce.widget.marketingitemlist",
    "epi/i18n!epi/nls/commerce.widget.marketingtoolbar",
    "dojo/text!./viewmodel/templates/DatePeriodColumnHeader.html"
], function (
// dojo
    array,
    declare,
    lang,
    aspect,
    all,
    dojoString,
    when,
// epi
    epiDate,
    _ModelBindingMixin,
// epi-cms
    ContentReference,
// epi-ecf-ui
    MarketingUtils,
    _ConfirmDiscardChangesMixin,
    _MarketingListBase,
    DiscountSelector,
    DiscountListModel,
// resources
    marketingResources,
    marketingToolbarResources,
    datePeriodColumnHeaderTemplate
) {
    return declare([_MarketingListBase, _ModelBindingMixin, _ConfirmDiscardChangesMixin], {
        // summary:
        //      A widget to list all promotions
        // tags:
        //      public

        // contextChangeEvent: [public] String
        //      Disable the double click action to grid item.
        contextChangeEvent: "",

        modelBindingMap: {
            "items": ["items"]
        },

        _discountSelectorDialog: null,

        startup: function () {
            // summary:
            //      Initialize data for grid.
            // tags:
            //      Protected
            this.inherited(arguments);

            this.refresh();
        },

        createModel: function () {
            return new DiscountListModel({ store: this.store });
        },

        getListSettings: function () {
            // summary:
            //      To override grid's store and dnd params
            // tags:
            //      Protected
            var self = this;

            return lang.mixin(this.inherited(arguments), {
                dndParams: {
                    alwaysCopy: false,
                    accept: [MarketingUtils.contentTypeIdentifier.promotionData],
                    // completely disable the grid's copy function by always returning false for the copyState
                    copyState: function (copyKeyPressed, self) {
                        return false;
                    }
                },
                showHeader: false,
                // Need set store to null, to prevent grid using query of store.
                store: null,
                onContextMenuClick: function (e) {
                    this.inherited(arguments);
                    self.onContextMenuClick(e);
                }
            });
        },

        onContextMenuClick: function (e) {
            // summary:
            //      Setup command model of selected row
            // tags:
            //      Protected

            this.inherited(arguments);
            var currentRowId = parseInt(this.grid.row(e).id, 10);
            this.model.updateCommandModel({ currentRowId: currentRowId });
        },

        setupEvents: function () {
            this.inherited(arguments);
            this.own(aspect.after(this.grid.dndSource, "onDropData", lang.hitch(this, this._onDndDrop), true));
        },

        refresh: function () {
            if (this.model) {
                this.model.fetchData();
            }
        },

        save: function () {
            // summary:
            //      Call save priority data
            // tags:
            //      Publish
            // return:
            //      Deferred object

            return this.model.save();
        },

        _onDndDrop: function (dndData, source, nodes, copy) {
            // summary:
            //      Topic event processor for /dnd/drop, called to finish the DnD operation.
            // tags:
            //      Private
            if (!this.grid.dndSource.current) {
                return;
            }
            if (this.grid.dndSource === source) {
                this.model.moveItem(nodes[0].rowIndex, this.grid.dndSource.getItem(this.grid.dndSource.current.id).data, this.grid.dndSource.before);
            }
        },

        _updateGrid: function (value) {
            // summary:
            //      Update the grid
            // tags:
            //      private
            if (this.grid && this.model) {
                this.grid.refresh();
                var itemsModel = value || this.model.get("items");
                if (itemsModel) {
                    this.grid.renderArray(itemsModel);
                }
            }
        },

        _setItemsAttr: function (value) {
            this._updateGrid(value);
        },

        getColumnSettings: function () {
            return {
                order: {
                    className: "epi-columnVeryNarrow epi-text--large",
                    sortable: false
                },
                name: {
                    className: "epi-grid--20",
                    get: lang.hitch(this.model, this.model._getNameModel),
                    formatter: lang.hitch(this, this._getNameHtml),
                    sortable: false
                },
                daterange: {
                    className: "epi-grid-column--centered",
                    get: lang.hitch(this.model, this.model._getStatusModel),
                    formatter: lang.hitch(this, this._getStatusHtml),
                    sortable: false
                },
                campaign: {
                    className: "epi-grid--20 epi-grid-column--centered",
                    get: function (item) {
                        return item.properties.campaignName;
                    },
                    sortable: false
                },
                exclusion: {
                    className: "epi-grid-column--left",
                    renderCell: lang.hitch(this, function (item) {
                        return this._getDiscountSelector(item).domNode;
                    }),
                    sortable: false
                }
            };
        },

        _getDiscountSelector: function (item) {
            var widget = new DiscountSelector({
                excludedLink: item.contentLink,
                dialog: this._discountSelectorDialog,
                ownDialog: false,
                campaignRootFolder: this.model.campaignRootFolder,
                store: this.model.store
            });

            if (!this._discountSelectorDialog) {
                this._discountSelectorDialog = widget.dialog;
                this.own(this._discountSelectorDialog);
            }

            widget._onChangeActive = false;
            var selectedLinks = item.properties.excludedItems || [];
            var selectedContents = [];
            all(array.map(selectedLinks, function (contentLink) {
                return when(this.model.store.get(contentLink), lang.hitch(this, function(content){
                    if (content) {
                        if (ContentReference.compareIgnoreVersion(content.contentLink, this.model.campaignRootFolder)) {
                            content.name = marketingToolbarResources.allcampaigns;
                        }

                        selectedContents.push(content);
                    }
                }));
            }, this)).then(function () {
                widget.set("value", selectedContents);
                widget._onChangeActive = true;
            });

            this.own(widget, widget.on("change", lang.hitch(this, function (selectedItems) {
                this.model.onSelectorValueChanged(item, selectedItems);
            })));
            return widget;
        },

        _getStatusHtml: function (model) {
            return dojoString.substitute(datePeriodColumnHeaderTemplate, {
                headingLabel: marketingResources.status[model.statusLabelKey],
                fromDate: epiDate.toUserFriendlyString(model.validFrom, null, null, true),
                toDate: epiDate.toUserFriendlyString(model.validUntil, null, null, true)
            });
        }
    });
});
